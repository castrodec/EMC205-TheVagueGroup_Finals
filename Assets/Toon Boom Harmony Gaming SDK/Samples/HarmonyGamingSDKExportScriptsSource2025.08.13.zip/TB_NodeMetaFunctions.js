
var kAnchorAttrName = "meta.game.isAnchor";
var kPropAttrName = "meta.game.isProp";

function ToggleBoolMeta( nodeName, attrName )
{
  var attr = node.getAttr(nodeName, 1.0, attrName);
  if( !attr || attr.keyword() == "" )
  {
    var visualAttrName = attrName;
    var idx = attrName.lastIndexOf(".");
    if (idx >= 0)
    {
      visualAttrName = attrName.substr(idx);
    }

    if (node.createDynamicAttr(nodeName, "BOOL", attrName, visualAttrName, false))
    {
      attr = node.getAttr(nodeName, 1.0, attrName);
    }

    if( attr && attr.keyword() != "" )
    {
      var isEnabled = attr.boolValue();
      node.setTextAttr(nodeName, attrName, 1.0, "true");

      return true;
    }
  }

  node.removeDynamicAttr(nodeName, attrName);
  return false;
}

function TB_ToggleCurrentNodePropMeta()
{
  if ( selection.numberOfNodesSelected() > 0 )
  {
    scene.beginUndoRedoAccum(translator.tr("Toggle Node Prop Meta"));

    for (var i=0 ; i<selection.numberOfNodesSelected() ; ++i )
    {
      var nodeName = selection.selectedNode(i);
      if ( nodeName == node.noNode() )
        continue;

      //  Toggle Prop Flag.
      var val = ToggleBoolMeta(nodeName, kPropAttrName);

      //  Remove Anchor Meta if set.
      node.removeDynamicAttr(nodeName, kAnchorAttrName);

      //  Change node color for easy identification in timeline.
      if (val)
        node.setColor( nodeName, new ColorRGBA( 0, 255, 0, 255 ) );
      else
        node.resetColor( nodeName );
    }

    scene.endUndoRedoAccum();
  }
}

function TB_ToggleCurrentNodeAnchorMeta()
{
  if ( selection.numberOfNodesSelected() > 0 )
  {
    scene.beginUndoRedoAccum(translator.tr("Toggle Node Anchor Meta"));

    for (var i=0 ; i<selection.numberOfNodesSelected() ; ++i )
    {
      var nodeName = selection.selectedNode(i);
      if ( nodeName == node.noNode() )
        continue;

      //  Toggle Anchor Flag.
      var val = ToggleBoolMeta(nodeName, kAnchorAttrName);

      //  Remove Prop Meta if set.
      node.removeDynamicAttr(nodeName, kPropAttrName);

      //  Change node color for easy identification in timeline.
      if (val)
        node.setColor( nodeName, new ColorRGBA( 255, 0, 0, 255 ) );
      else
        node.resetColor( nodeName );
    }

    scene.endUndoRedoAccum();
  }
}

/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var PostProcess = require("./TB_PostProcess.js");
var CurveProcess = PostProcess.CurveProcess;
var GameExportUtil = require("./TB_GameExportUtil.js").GameExportUtil;
var NodeUtil = require("./TB_NodeUtil.js");
var ObjUtil = require("./TB_ObjUtil.js");
var FileUtil = require("./TB_FileUtil.js");
var ProgressBar = require("./TB_ProgressBar.js").ProgressBar;
var Iter = require("./TB_Iter.js").Iter;
var XML = require("./TB_XMLBuilder.js");
var GameFileEncoder = require("./TB_GameFileEncoder.js");
/**
 * @param {Settings & { 
 *  hideProgress?: boolean,
 * }} settings
 * @param {ProgressBar} progressBar
 */
exports.GameExport = function(settings, progressBar) {

  var curveProcess = new CurveProcess(settings.unitScale);
  var exportVersion = settings.encodeToTBG ? 3 : 1;
  var gameExportUtil = new GameExportUtil({
    exportVersion: exportVersion,
    unitScale: settings.unitScale,
    includeOverlayAndUnderlay: settings.includeOverlayAndUnderlay,
    bakeAllGroups: settings.bakeAllGroups,
  });

  /**
   * Parse Harmony node graph to gather basic information
   * about what nodes will be processed and when.
   */

  var _progress = new progressBar.Process({ title: "Gathering data", items: 3 });
  /**
   * Node graph parsing.
   */

  _progress.tryIncrementCancellable(translator.tr("Parsing node graph..."));

  var displayPath = scene.getDefaultDisplay();
  if (displayPath == "Unconnected_Display") {
    progressBar.close();
    throw new Error("No display node found.");
  }

  var notABakeGroupOrDisabled = NodeUtil.notABakeGroupOrDisabledFunc(settings);

  var acceptReadNodes = function(/**@type NodePath*/nodePath) { return NodeUtil.getNodeGameTag(settings, nodePath) == "read" };
  /**@type RenderableNodePaths*/
  var renderableNodePaths = {
    bake: new NodeUtil.InputScan(displayPath, {
      isMatch: function(nodePath) { return settings.bakeAllGroups ? node.isGroup(nodePath) : (NodeUtil.getNodeGameTag(settings, nodePath) == "bake") },
      shouldEnterGroupNode: notABakeGroupOrDisabled,
    }).toArray(),
    read: new NodeUtil.InputScan(displayPath, {
      isMatch: acceptReadNodes,
      shouldEnterGroupNode: notABakeGroupOrDisabled,
    }).toArray(),
  };

  /**
   * Gather metadata from Scene/Nodes.
   */

  _progress.tryIncrementCancellable(translator.tr("Parsing metadata / skins..."));

  var sceneGameMetas = scene.metadatas().filter(function(metadata) {
    return metadata.name.search("game.") == 0;
  });



  var sceneMarkerMetas = scene.metadatas().filter(function(metadata) {
    return metadata.name.search("sceneMarkers.") == 0;
  });

  /**@type NodePathToMeta*/
  var nodePathToMeta = ObjUtil.fromEntries(ObjUtil.keys(new NodeUtil.InputScan(displayPath).toLookup()).reverse()
    .map(function(nodePath) {
      var drawingNameToIdx = gameExportUtil.generateDrawingNameToIdx(node.linkedColumn(nodePath, "drawing.element"));
      var customMetasEntries = node.getAttrList(nodePath, 1, "meta.game")
        .map(function(attr) { return { key: attr.fullKeyword(), value: attr.textValue() }; });
      var groupAttr = node.getAttr(nodePath, 1, "meta.nodegroup");
      var skinsEntries = node.getAttrList(nodePath, 1, "meta.skin")
        .map(function(attr) { return attr.keyword(); })
        .map(function(skinName) {
          var animationEntries = node.getAttrList(nodePath, 1, "meta.skin_" + skinName)
            .map(function(attr) {
              var animationName = attr.fullKeyword().substring("meta.skin_".length).split(".")[1]; // "skin_(skin).>animation<"
              var keyframeInfo = attr.textValue().split(";"); // "idx;exp;idx;exp;..."
              var keyframes = [];
              for (var i = 0; i < keyframeInfo.length; i += 2) {
                var drawingName = keyframeInfo[i];
                keyframes.push({
                  spriteIdx: drawingNameToIdx[drawingName],
                  exposure: parseFloat(keyframeInfo[i + 1])
                });
              }
              return {
                key: PostProcess.safeAnimationName(animationName),
                value: keyframes,
              }
            });
          return {
            key: PostProcess.safeSkinName(skinName),
            value: ObjUtil.fromEntries(animationEntries),
          };
        });
      var customMetas = customMetasEntries.length == 0 ? undefined : ObjUtil.fromEntries(customMetasEntries);
      var group = groupAttr == null ? undefined : groupAttr.textValue();
      var skinToAnimationToKeyframes = skinsEntries.length == 0 ? undefined : ObjUtil.fromEntries(skinsEntries);
      var isAnchor, isProp = undefined;
      if (customMetas != null) {
        isAnchor = customMetas["meta.game.isAnchor"] != null;
        isProp = customMetas["meta.game.isProp"] != null;
        delete customMetas["meta.game.isAnchor"];
        delete customMetas["meta.game.isProp"];
      }
      return {
        key: PostProcess.safeNodePath(nodePath),
        value: customMetas || group || skinToAnimationToKeyframes ? {
          anchorPropMode: isAnchor ? "anchor" : isProp ? "prop" : undefined,
          customMetas: customMetas,
          group: group,
          skinToAnimationToKeyframes: skinToAnimationToKeyframes,
        } : undefined,
      };
    }));

  /**
   * Gather skins and groups, assign unique ID for XML.
   */

  var skinToID = /**@type Lookup<SkinName, number>*/({ none: 0 });
  var groupNameToID = /**@type Lookup<string, number>*/({});
  (function gatherGroupsAndSkins() {
    var nextSkinId = 1;
    var nextGroupId = 1;
    ObjUtil.keys(nodePathToMeta).forEach(function(nodePath) {
      var metas = nodePathToMeta[nodePath];
      if (metas == null)
        return;
      if (metas.skinToAnimationToKeyframes != null) {
        ObjUtil.keys(metas.skinToAnimationToKeyframes).forEach(function(skinName) {
          if (skinToID[skinName] != null || skinName == "skin.Empty")
            return;
          skinToID[skinName] = nextSkinId++;
        });
      }
      if (metas.group != null) {
        if (groupNameToID[metas.group] != null)
          return;
        groupNameToID[metas.group] = nextGroupId++;
      }
    });
  })()

  /**
   * XSheet / Timeline parsing.
   */

  _progress.tryIncrementCancellable(translator.tr("Calculating sprites..."));

  var riggingName = scene.currentScene();
  var animationToMarker = NodeUtil.animationToSceneMarker(PostProcess.safeAnimationName);

  var unfilteredDrawings = gameExportUtil.getDrawingDataForNodes(renderableNodePaths, nodePathToMeta, skinToID, animationToMarker, _progress);

  _progress.tryIncrementCancellable(translator.tr("Filtering hidden nodes..."));

  var drawings = {
    spriteIdxLookup: unfilteredDrawings.spriteIdxLookup,
    uniqueFrameLookup: ObjUtil.fromEntries(ObjUtil.entries(unfilteredDrawings.uniqueFrameLookup)
      .filter(function(uniqueFrames) {
        // Filter out frames that aren't visible on export.
        var nodePath = uniqueFrames.key;
        // skip disabled nodes
        if (!node.getEnable(nodePath)) {
          MessageLog.trace("Node " + nodePath + " excluded for being disabled.");
          return false;
        }
        var baked = NodeUtil.getNodeGameTag(settings, nodePath) == "bake";
        var visible = baked || uniqueFrames.value.some(function(uniqueFrame) {
          if (uniqueFrame == null) return false;
          return NodeUtil.withTempSkinSwappedDrawingsAtFrame({
            skinName: uniqueFrame.skinName,
            nodePaths: [nodePath],
            spriteIdxLookup: unfilteredDrawings.spriteIdxLookup,
            timelineFrame: uniqueFrame.timelineFrame,
            preRegisterUndo: false,
          }, function() {
            return NodeUtil.isReadNodeVisible(nodePath, uniqueFrame.timelineFrame);
          });
        });
        if (!visible)
          MessageLog.trace("Node " + nodePath + " excluded for being an empty drawing.");
        return visible;
      }))
  };

  var spriteSheetXML = /**@type XML.Blueprint | null*/(null);

  _progress.tryIncrementCancellable(translator.tr("Building skeleton..."));

  function isAnchor(/**@type NodePath*/nodePath) {
    var meta = nodePathToMeta[nodePath];
    if (meta != null && meta.anchorPropMode == "anchor") {
      return true;
    }
  }
  function isProp(/**@type NodePath*/nodePath) {
    var meta = nodePathToMeta[nodePath];
    if (meta != null && meta.anchorPropMode == "prop") {
      return true;
    }
  }
  function isValidForSkeleton(/**@type NodePath*/nodePath) {
    if (NodeUtil.getNodeGameTag(settings, nodePath) != "read") {
      return true;
    }
    if (isProp(nodePath)) {
      return false;
    }
    if (isAnchor(nodePath)) {
      return true;
    }
    return !settings.excludeEmptyDrawings || drawings.uniqueFrameLookup[nodePath] != null;
  }
  var anchorNodesLookup = ObjUtil.fromEntries(renderableNodePaths.read
    .filter(isAnchor)
    .map(function(nodePath) {
      return { key: nodePath, value: /**@type const*/(true) };
    }));

  // Build the skeleton.
  /**
   * @param {NodePath} nodePath
   * @param {number} inputPortIndex
   */
  var inputTransitionsToMatte = function(nodePath, inputPortIndex) {
    if (inputPortIndex == 1) {
      var gameTag = NodeUtil.getNodeGameTag(settings, nodePath);
      return gameTag == "cutter" || gameTag == "inverseCutter";
    }
    return false;
  };
  var compositeReads = new NodeUtil.InputScan(displayPath, {
    isMatch: acceptReadNodes,
    shouldEnterGroupNode: notABakeGroupOrDisabled,
    shouldQuitBranch: inputTransitionsToMatte,
  }).toLookup();
  var linkGeneratorCallbacks = /**@type LinkGeneratorCallbacks*/({
    shouldEnterGroupNode: notABakeGroupOrDisabled,
    isMatch: function(nodePath) {
      var gameTag = NodeUtil.getNodeGameTag(settings, nodePath);
      return gameTag != "invalid" && gameTag != "ignored" && isValidForSkeleton(nodePath)
    },
    shouldDeferInputToSeperateChain: function(nodePath, inputPortIndex, inputNodePath) {
      if (!inputTransitionsToMatte(nodePath, inputPortIndex))
        return false;
      return compositeReads[inputNodePath] != null;
    },
    branchIsVisible: function(nodePath, inputPortIndex) {
      return !inputTransitionsToMatte(nodePath, inputPortIndex);
    },
    shouldDuplicateNode: function(nodePath, isVisible) {
      return isVisible && NodeUtil.getNodeGameTag(settings, nodePath) == "read";
    }
  });
  var links = exportVersion == 1
    ? NodeUtil.uncrossLinks(settings, displayPath, linkGeneratorCallbacks)
    : NodeUtil.generateRenderSortedLinks(settings, displayPath, linkGeneratorCallbacks);
  var skeleton = gameExportUtil.buildSkeleton(links);

  _progress.tryIncrementCancellable(translator.tr("Finding sound columns..."));

  // Find sound columns.
  var soundSequences = /**@type SoundSequence[]*/([]);
  var numColumns = column.numberOf();
  for (var columnIdx = 0; columnIdx < numColumns; ++columnIdx) {
    var columnName = column.getName(columnIdx);
    if (column.type(columnName) != "SOUND") {
      continue;
    }
    var soundColumn = column.soundColumn(columnName);
    if (!soundColumn) {
      continue;
    }
    var sequences = soundColumn.sequences();
    var numSequences = sequences.length;
    for (var sequenceIdx = 0; sequenceIdx < numSequences; ++sequenceIdx) {
      soundSequences.push(sequences[sequenceIdx]);
    }
  }

  // We need to build a persistent list of spritePaths from the nodePath and spriteIndex, as the operating system could be case insensitive, requiring we resolve name collisions.
  var existingSpritePaths = /**@type Record<string, boolean>*/({});
  var nodePathSpriteIndexToName = ObjUtil.fromEntries(
    ObjUtil.keys(drawings.uniqueFrameLookup)
      .map(function(nodePath) {
        return {
          key: nodePath, value: ObjUtil.fromEntries(
            drawings.uniqueFrameLookup[nodePath]
              .map(function(uniqueFrame, spriteIndex) {
                if (uniqueFrame == null)
                  return null;
                var columnName = node.linkedColumn(nodePath, "DRAWING.ELEMENT");
                var nameOrExposure = column.getEntry(columnName, 1, uniqueFrame.timelineFrame);
                var spritePath = PostProcess.nodePathAndSprite(nodePath, nameOrExposure, existingSpritePaths);
                return { key: spriteIndex, value: spritePath };
              })
              .filter(Iter.notNull)),
        };
      }));

  _progress.tryIncrementCancellable(translator.tr("Calculating palette variations..."));


  this.paletteVariations = NodeUtil.paletteVariationsFromDisplayPath(displayPath, settings);

  if (this.paletteVariations.length == 0) {
    this.paletteVariations = [{ fileName: "default", uiName: "default", groupsOfPaletteIDs: [] }];
  }

  this.drawings = drawings;

  this.animationNames = ObjUtil.values(animationToMarker).map(function(marker) {
    return marker.name;
  });

  this.tryExportAudio = function() {

    new progressBar.Process({
      title: "Exporting Audio",
      items: 1,
    });

    var outputFolder = FileUtil.ensureFolderStructureExists(exportPath(), ["audio"]);

    var sourceAudioCopied = /**@type Record<string, boolean>*/({});
    soundSequences.forEach(function(sequence) {
      var sourcePath = sequence.filename;
      var fileName = sourcePath.split("/").slice(-1)[0];
      if (sourceAudioCopied[sourcePath]) {
        return;
      }
      var dstPath = [outputFolder, fileName].join("/");
      var dstFile = new PermanentFile(dstPath);
      var srcFile = new PermanentFile(sourcePath);
      srcFile.copy(dstFile);
      sourceAudioCopied[sourcePath] = true;
    });

    return this;
  }

  function exportPath() {
    if (!settings.encodeToTBG) {
      return FileUtil.ensureFolderStructureExists(
        settings.savingPath,
        [settings.savingName]);
    }
    else {
      return FileUtil.ensureFolderStructureExists(scene.currentProjectPathRemapped(), ["temp_export"]);
    }
  }

  /**
   * Render out sprites.
   * Optionally generate texture atlas (sprite sheet).
   */
  this.tryRenderSprites = function() {

    var _progress = new progressBar.Process({
      title: "Rendering Sprites",
      items: ObjUtil.keys(settings.spriteResolutions).length
        * this.paletteVariations
          .filter(function(paletteVariation) {
            var paletteSetting = settings.exportPalettes[paletteVariation.uiName];
            return paletteSetting == null || !paletteSetting.exclude;
          })
          .length
        * new Iter(ObjUtil.keys(drawings.uniqueFrameLookup))
          .flatMap(function(nodePath) { return drawings.uniqueFrameLookup[nodePath]; })
          .length,
    });

    /**
     * Render all sprites. Need to find ideal timeline frame to render each unique drawing per-node.
     * Information from rendering process is carried into spriteSheet creation process.
     */
    var outputFolder = exportPath();

    if (settings.clearTextureFolder) {
      new QFile(outputFolder + "/spriteSheets.xml").remove();
      FileUtil.removeFolder(outputFolder + "/sprites");
      FileUtil.removeFolder(outputFolder + "/spriteSheets");
    }

    var includedVariations = this.paletteVariations.filter(function(paletteVariation) {
      var paletteSettings = settings.exportPalettes[paletteVariation.uiName];
      return paletteSettings == null || !paletteSettings.exclude
    });

    includedVariations.forEach(function(paletteVariation) {

      scene.beginUndoRedoAccum("Clone Palettes");

      // Clone new palettes to represent this variation.
      var paletteList = PaletteObjectManager.getScenePaletteList();
      var clonedPalettes = new Iter(paletteVariation.groupsOfPaletteIDs)
        .flatMap(function(group) { return group })
        .reverse()
        .map(function(paletteID) {
          var palette = paletteList.getPaletteById(paletteID);
          var clonedPalette = paletteList.createPalette("palette-library/" + palette.getName() + NodeUtil.clonedPaletteSuffix, 0);
          for (var colorIdx = 0; colorIdx < palette.nColors; ++colorIdx) {
            clonedPalette.cloneColor(palette.getColorByIndex(colorIdx));
          }
          return clonedPalette;
        });

      Utransform.resetPalettes();
      scene.endUndoRedoAccum();

      scene.saveAll(); // Save so that palette cloning changes are applied during export.
      try {
        return ObjUtil.keys(settings.spriteResolutions)
          .map(function(spriteResName) {

            var renderResolution = gameExportUtil.calculateRenderResolution(settings.spriteResolutions[spriteResName]);

            var renderIntermediateFolder = FileUtil.ensureFolderStructureExists(
              outputFolder,
              ["sprites", "sheet_" + riggingName, spriteResName + "-" + paletteVariation.fileName]);

            var spriteToRenderInfo = ObjUtil.fromEntries(
              new Iter(ObjUtil.keys(drawings.uniqueFrameLookup))
                .flatMap(function(nodePath) {
                  return drawings.uniqueFrameLookup[nodePath].map(function(uniqueFrame, spriteIndex) {

                    if (uniqueFrame == null)
                      return null;

                    var spritePath = nodePathSpriteIndexToName[nodePath][spriteIndex];

                    _progress.tryIncrementCancellable(translator.tr("Rendering sprite"), spritePath.split("/").pop());

                    var outputPath = renderIntermediateFolder + "/" + spritePath;

                    // Render sprites or bake groups.
                    var renderInfo =
                      NodeUtil.getNodeGameTag(settings, nodePath) != "bake"
                        ? gameExportUtil.exportNode({
                          resolution: renderResolution,
                          nodePath: nodePath,
                          spriteIndex: spriteIndex,
                          outputPath: outputPath
                        })
                        : gameExportUtil.bakeNode({
                          spriteIdxLookup: drawings.spriteIdxLookup,
                          skinName: uniqueFrame.skinName,
                          resolution: renderResolution,
                          nodePath: nodePath,
                          timelineFrame: uniqueFrame.timelineFrame,
                          outputPath: outputPath,
                          willUseCroppedRect: !settings.individualSprites,
                        });

                    if (renderInfo == null) {
                      MessageLog.trace("Failed to render sprite: " + spritePath);
                      return null;
                    }

                    FileUtil.saveString(outputPath + ".sprite", new XML.Builder({
                      tag: "crop",
                      attributes: {
                        centreX: -renderInfo.originOffset.x,
                        centreY: -renderInfo.originOffset.y,
                        pivotX: -renderInfo.originOffset.x,
                        pivotY: -renderInfo.originOffset.y,
                        scaleX: renderInfo.scale.x,
                        scaleY: renderInfo.scale.y,
                        rectX: renderInfo.croppedRect.x,
                        rectY: renderInfo.croppedRect.y,
                        rectWidth: renderInfo.croppedRect.width,
                        rectHeight: renderInfo.croppedRect.height,
                      }
                    }).toXMLString());

                    return {
                      key: spritePath,
                      value: renderInfo,
                    };
                  });
                })
                .filter(Iter.notNull));

            return { key: spriteResName, value: spriteToRenderInfo };
          })
      }
      finally {
        // Undo palette cloning.
        scene.undo();
        scene.clearRedo();

        // Manually delete palette files using QFile interface.
        clonedPalettes
          .map(NodeUtil.getPalettePath)
          .filter(Iter.notNull)
          .forEach(function(path) {
            new QFile(path).remove();
          });

        // Save project.
        scene.saveAll();
      }
    });

    /**
     * Compose atlas from individual sprite files.
     */

    var spriteSheetPath = outputFolder + "/spriteSheets.xml";
    if (settings.individualSprites) {
      FileUtil.removeFolder(outputFolder + "/spriteSheets");
    }
    else {
      _progress = new progressBar.Process({
        title: "Generating Atlases for Resolution",
        items: ObjUtil.keys(settings.spriteResolutions).length,
      });

      for (var spriteResName in settings.spriteResolutions) {
        this.paletteVariations.forEach(function(paletteVaration) {

          _progress.tryIncrementCancellable(spriteResName.toUpperCase());

          var atlasGenerationResult = gameExportUtil.generateTextureAtlas({
            textureFolder: outputFolder + "/sprites",
            rootFolder: outputFolder,
            riggingName: riggingName,
            spriteResName: spriteResName + "-" + paletteVaration.fileName,
            resX: settings.maxWidth,
            resY: settings.maxHeight,
            fixedResolution: settings.fixResolution,
            resType: settings.resolutionType,
            reuseFramesThreshold: !settings.reuseFrames ? -1 : settings.reuseFramesThreshold,
            maxSpriteSheet: 1,
          });

          if (atlasGenerationResult != "success") {
            MessageBox.warning(atlasGenerationResult.error, MessageBox.Ok, MessageBox.NoButton);
            throw Error(atlasGenerationResult.error);
          }

          var path = ["spriteSheets", "sheet_" + riggingName, spriteResName + "-" + paletteVaration.fileName].join("/");
          MessageLog.trace("Saved sprite sheet at " + path);
        });
      }

      FileUtil.removeFolder(outputFolder + "/sprites");

      /**
       * Load file, delete and compose updated XML format. Ensure each child element has a unique 'filename' attribute.
       */

      var spriteSheetString = FileUtil.readString(spriteSheetPath);
      if (spriteSheetString == null)
        throw "spriteSheets.xml not found";

      var originalSpriteSheets = /**@type SpriteSheetsXMLBlueprint*/(XML.Blueprint.fromXMLString(spriteSheetString));
      var uniqueChildrenLookup = ObjUtil.fromEntries((originalSpriteSheets.children || [])
        .map(function(child) { return { key: child.attributes.filename, value: child } }));
      spriteSheetXML = {
        tag: originalSpriteSheets.tag,
        children: ObjUtil.keys(uniqueChildrenLookup)
          .map(function(key) {
            return uniqueChildrenLookup[key];
          }),
      };
    }
    new QFile(spriteSheetPath).remove();

    return this;
  }

  /** @type Record<NodePath, DeformAnimationData> */
  var deformAnimData = {}
  skeleton.nodes.map(function(nodeInfo) {
    if (nodeInfo.tag == "mesh") {
      var anim_data = deformation.getShapeAwareModuleMesh({ module: nodeInfo.path });
      deformAnimData[nodeInfo.path] = anim_data;
    }
  })

  /**
   * Generate scene XML documents.
   */
  this.trySaveXMLFiles = function() {

    var blueprintCallbacks = [
      /**
       * @returns {XMLBlueprint}
       */
      function deformationAnimationsXML() {
        _progress.tryIncrementCancellable("deformationNodes.xml");
        var positionScale = scene.numberOfUnitsY() / 2 * settings.unitScale;
        return {
          tag: "deformationNodes",
          children: ObjUtil.entries(deformAnimData).map(function(entry) {
            var nodePath = entry.key;
            var data = entry.value;
            return {
              tag: "deformationNode",
              attributes: { name: NodeUtil.nodePath(nodePath) },
              children:
                [
                  {
                    tag: "animations",
                    children: ObjUtil.entries(animationToMarker).map(function(entry) {
                      var timelineMarker = entry.value;
                      return {
                        tag: "animation",
                        attributes: { name: timelineMarker.name },
                        children: data.frames
                          .slice(timelineMarker.frame - 1, timelineMarker.frame - 1 + timelineMarker.length)
                          .map(function(frame) {
                            if (frame == false)
                              return { tag: "empty" };
                            return {
                              tag: "frame",
                              attributes: { index: frame.frame - timelineMarker.frame + 1 },
                              children: frame.boneTransformations.map(function(transform) {
                                return {
                                  tag: "bone", attributes: {
                                    rx: transform[0],
                                    ry: transform[1],
                                    ux: transform[2],
                                    uy: transform[3],
                                    ox: transform[4] * positionScale,
                                    oy: transform[5] * positionScale,
                                  }
                                };
                              }),
                            };
                          })
                      };
                    }),
                  },
                  {
                    tag: "meshes",
                    children: ObjUtil.entries(data.meshes).map(function(meshEntry) {
                      var mesh = meshEntry.value;
                      return {
                        tag: "drawing",
                        attributes: { name: meshEntry.key, numBonesInVertices: mesh.numBonesInVertices },
                        children: [
                          {
                            tag: "triangles",
                            children: mesh.triangles.map(function(triangle) {
                              return { tag: "tri", attributes: triangle };
                            })
                          },
                          {
                            tag: "vertices",
                            children: mesh.vertices.map(function(vertex, i) {
                              return {
                                tag: "vert",
                                attributes: { x: vertex.x * positionScale, y: vertex.y * positionScale },
                                children: ObjUtil.entries(mesh.weights[i]).map(function(weightEntry) {
                                  return { tag: "bone", attributes: { i: weightEntry.key, w: weightEntry.value } };
                                }),
                              };
                            })
                          },
                        ]
                      }
                    })
                  },
                ]
            };
          })
        }
      },
      /**
       * @returns {XMLBlueprint}
       */
      function stageXML() {
        _progress.tryIncrementCancellable("stage.xml");
        return {
          tag: "stages",
          attributes: { version: exportVersion },
          children: ObjUtil.entries(animationToMarker).map(function(entry) {
            var marker = entry.value;
            var markerMetasLookup = {
              loop: false,
              facing: "None",
              mode: "None",
            };
            var markerMetas = ObjUtil.fromEntries(ObjUtil.entries(markerMetasLookup).map(function(metaLookup) {
              var matchingMetas = sceneMarkerMetas.filter(function(markerMeta) {
                MessageLog.trace(markerMeta.name);
                return markerMeta.name == "sceneMarkers.extraData." + marker.name + "." + metaLookup.key
              });
              if (matchingMetas.length > 0) {
                MessageLog.trace("Found!");
                return { key: metaLookup.key, value: matchingMetas[0].value }
              }
              return { key: metaLookup.key, value: "" + metaLookup.value };
            }));
            var finalAnimationName = marker.name;
            var children = /**@type XMLBlueprint[]*/([])
              .concat(sceneGameMetas.map(function(meta) {
                return { tag: "meta", attributes: { name: meta.name, value: meta.value } };
              }))
              .concat(ObjUtil.entries(skinToID).map(function(entry) {
                return { tag: "skin", attributes: { skinId: entry.value, name: PostProcess.skinName(entry.key) } };
              }))
              .concat(ObjUtil.entries(groupNameToID).map(function(entry) {
                return { tag: "group", attributes: { groupId: entry.value, name: entry.key } };
              }))
              .concat(ObjUtil.keys(anchorNodesLookup).map(function(nodePath) {
                return { tag: "anchor", attributes: { node: NodeUtil.nodePath(nodePath), play: PostProcess.skeleton(skeleton.rootNodePath) } };
              }))
              .concat(new Iter(ObjUtil.entries(nodePathToMeta)).flatMap(function(entry) {
                if (entry.value == null || entry.value.customMetas == null)
                  return [];
                return ObjUtil.entries(entry.value.customMetas).map(function(meta) {
                  return { tag: "meta", attributes: { node: entry.key, name: meta.key, value: meta.value } };
                });
              }))
              .concat(ObjUtil.keys(drawings.uniqueFrameLookup).map(function(nodePath, drawingIdx) {
                var skins = ObjUtil.keys(drawings.spriteIdxLookup[nodePath])
                  .map(function(key) { return skinToID[key] })
                  .filter(Iter.notNull)
                var metadata = nodePathToMeta[nodePath];
                var group = metadata != null
                  ? metadata.group
                  : node.isGroup(nodePath)
                    ? node.subNodes(nodePath)
                      .map(function(subNodePath) { return nodePathToMeta[subNodePath]; })
                      .map(function(metadata) { return metadata == null ? null : metadata.group; })
                      .filter(Iter.notNull)[0]
                    : null;
                return {
                  tag: "node",
                  attributes: {
                    drwId: PostProcess.indexToDrwID(drawingIdx),
                    name: NodeUtil.nodePath(nodePath),
                    groupId: group == null ? 0 : groupNameToID[group],
                    skinId: skins.join(","),
                  },
                };
              }))
              .concat([{
                tag: "play",
                attributes: {
                  name: finalAnimationName,
                  skeleton: PostProcess.skeleton(skeleton.rootNodePath),
                  animation: finalAnimationName,
                  drawingAnimation: finalAnimationName,
                  framerate: scene.getFrameRate(),
                  markerLength: marker.length,
                  loop: markerMetas.loop,
                  facing: markerMetas.facing,
                  mode: markerMetas.mode,
                },
              }])
              .concat(soundSequences
                .filter(function(sequence) {
                  return sequence.startFrame < marker.frame + marker.length && sequence.stopFrame > marker.frame;
                })
                .map(function(sequence) {
                  return { tag: "sound", attributes: { name: sequence.name, time: sequence.startFrame - marker.frame + 1 } };
                }))
            return {
              tag: "stage",
              attributes: {
                name: finalAnimationName,
                unitWidth: curveProcess.scaleConstant("POSITION.Y", scene.numberOfUnitsY() * scene.currentResolutionX() / scene.currentResolutionY()),
                unitHeight: curveProcess.scaleConstant("POSITION.Y", scene.numberOfUnitsY()),
                resolutionWidth: scene.currentResolutionX(),
                resolutionHeight: scene.currentResolutionY(),
              },
              children: children
            };
          }),
        };
      },
      /**
       * @returns {OverwriteXMLBlueprint}
       */
      function skeletonXML() {
        _progress.tryIncrementCancellable("skeleton.xml");
        var filepath = FileUtil.currentScenePath();
        var path = FileUtil.currentProjectPath();
        for (var _path = path; _path != ""; _path = FileUtil.parentFolder(_path)) {
          var temp_path = _path + "/Assets";
          if (FileUtil.folderExists(temp_path)) {
            path = temp_path;
            break;
          }
        }
        var dir = new QDir(path);
        return {
          overwrite: settings.overwriteProject,
          tag: "skeletons",
          attributes: { version: exportVersion, tgspath: dir.relativeFilePath(filepath) },
          mergeChildAttribute: "name",
          children: [{
            tag: "skeleton", attributes: { name: PostProcess.skeleton(skeleton.rootNodePath) }, children: [{
              tag: "nodes", children: skeleton.nodes
                .map(function(nodeInfo) {
                  return {
                    tag: PostProcess.nodeTypeToSkeletonTag(nodeInfo.path, nodeInfo.tag, anchorNodesLookup),
                    attributes: {
                      id: nodeInfo.id,
                      name: NodeUtil.nodePath(nodeInfo.path),
                      visible: NodeUtil.getNodeGameTag(settings, nodeInfo.path) == "read"
                        ? compositeReads[nodeInfo.path]
                          ? true
                          : false
                        : undefined,
                    },
                  }
                }),
            }, {
              tag: "links", children: skeleton.numberedLinks
                .map(function(link) { return { tag: "link", attributes: link } }),
            }]
          }],
        }
      },
      /**
       * @returns {OverwriteXMLBlueprint}
       */
      function drawingAnimationXML() {
        _progress.tryIncrementCancellable("drawingAnimation.xml");
        return {
          overwrite: settings.overwriteProject,
          tag: "drawingAnimations",
          attributes: { version: exportVersion },
          mergeChildAttribute: "name",
          children: ObjUtil.keys(animationToMarker)
            .map(function(animationName) {
              var timelineMarker = animationToMarker[animationName];
              return {
                tag: "drawingAnimation",
                attributes: {
                  name: timelineMarker.name,
                  spritesheet: "sheet_" + riggingName
                },
                children: ObjUtil.keys(drawings.uniqueFrameLookup)
                  .filter(function(nodePath) {
                    return !anchorNodesLookup[nodePath]
                  })
                  .map(function(nodePath, drawingIdx) {
                    return {
                      tag: "drawing",
                      attributes: {
                        name: NodeUtil.nodePath(nodePath),
                        node: NodeUtil.nodePath(nodePath),
                        drwId: PostProcess.indexToDrwID(drawingIdx)
                      },
                      children: new Iter(ObjUtil.keys(drawings.spriteIdxLookup[nodePath]))
                        .flatMap(function(skinName) {
                          var timelineToUniqueFrame = drawings.spriteIdxLookup[nodePath][skinName];
                          if (timelineToUniqueFrame == null)
                            return [];
                          var markerToUniqueFrame = timelineToUniqueFrame
                            .slice(timelineMarker.frame - 1, timelineMarker.frame - 1 + timelineMarker.length);
                          var animationKeyframes = gameExportUtil.generateAnimationKeyframes(markerToUniqueFrame);
                          return animationKeyframes
                            .map(function(element) {
                              var skinId = skinToID[skinName];
                              return {
                                tag: "drw",
                                attributes: {
                                  skinId: skinId != null ? skinId : 0,
                                  name: nodePathSpriteIndexToName[nodePath][element.spriteIdx],
                                  frame: element.timelineFrame,
                                  repeat: element.exposure,
                                },
                              };
                            });
                        }),
                    };
                  }),
              }
            }),
        };
      },
      /**
       * @returns {OverwriteXMLBlueprint}
       */
      function animationXML() {
        _progress.tryIncrementCancellable("animation.xml", "Gathering Attributes");
        var modifiedAnimationAttributes = new Iter(skeleton.nodes)
          .flatMap(function(nodeInfo) {
            return NodeUtil
              .findModifiedAttributesForNode(nodeInfo.path, {
                precalculateBezier: settings.precalculateBezier,
                attributeWhitelist: curveProcess.attributeWhitelist
              })
              .map(function(attrInfo) { return { nodePath: nodeInfo.path, attr: attrInfo }; })
          })
          .concat(skeleton.deformations.toAttributes())
          .map(function(info) {
            /**@type AttributeInfo*/
            var attr = "constant" in info.attr ? {
              path: info.attr.path,
              constant: curveProcess.scaleConstant(info.attr.path, info.attr.constant),
            } : {
              path: info.attr.path,
              column: info.attr.column,
              curve: curveProcess.scaleCurve(info.attr.path, info.attr.curve),
            };
            if (curveProcess.isDefault(attr)) {
              return null;
            }
            return {
              nodePath: info.nodePath,
              attr: attr,
            };
          })
          .filter(Iter.notNull);

        return {
          overwrite: settings.overwriteProject,
          tag: "animations",
          attributes: { version: exportVersion },
          mergeChildAttribute: "name",
          children: ObjUtil.keys(animationToMarker)
            .map(function(animationName) {
              var timelineMarker = animationToMarker[animationName];

              _progress.tryIncrementCancellable("animation.xml", animationName + " - Transforming Attributes");

              /** @typedef {{nodePath: NodePath, attr: ProcessedAttributeInfo}} TransformedAttribute*/
              var transformedAttributes = modifiedAnimationAttributes
                .map(function(info) {
                  if (!("curve" in info.attr)) {
                    return /**@type TransformedAttribute*/({ nodePath: info.nodePath, attr: info.attr });
                  }
                  var curve = NodeUtil.trimAndOffsetCurve(info.attr.curve, timelineMarker.frame, timelineMarker.length);
                  var column = info.attr.column;
                  var attr = {
                    path: info.attr.path,
                    column: column,
                    curve: curve,
                  };
                  return /**@type TransformedAttribute*/({ nodePath: info.nodePath, attr: attr });
                })
                .filter(Iter.notNull);

              _progress.tryIncrementCancellable("animation.xml", animationName + " - Transformed Attributes");

              var attrLinkBlueprints = transformedAttributes
                .map(function(info) {
                  var attrPath = PostProcess.attributePath(info.attr.path);
                  return /**@type XML.Blueprint*/({
                    tag: "attrlink",
                    attributes: "column" in info.attr
                      ? {
                        node: NodeUtil.nodePath(info.nodePath),
                        attr: attrPath,
                        timedvalue: info.attr.column,
                        iskeyed: NodeUtil.checkForOverlappingKeyframes(info.attr, timelineMarker.frame, timelineMarker.length),
                      }
                      : "pivot" in info.attr
                        ? {
                          node: NodeUtil.nodePath(info.nodePath),
                          attr: attrPath,
                          timedvalue: NodeUtil.nodePathToPivot(info.nodePath),
                          iskeyed: true,
                        }
                        : {
                          node: NodeUtil.nodePath(info.nodePath),
                          attr: attrPath,
                          value: info.attr.constant,
                          iskeyed: false,
                        }
                  });
                });

              _progress.tryIncrementCancellable("animation.xml", animationName + " - Timed Values");

              var timedValueBlueprints = transformedAttributes
                .map(function(info) {
                  if ("constant" in info.attr)
                    return null;
                  if ("column" in info.attr) {
                    var columnType = info.attr.curve.type;
                    return /**@type XML.Blueprint*/({
                      tag: curveProcess.columnTypeToTimedValue[columnType] || columnType.toLowerCase(),
                      attributes: { name: info.attr.column },
                      children: info.attr.curve.points
                        .map(function(point) {
                          return { tag: "pt", attributes: point };
                        })
                    });
                  }
                  return null;
                })
                .filter(Iter.notNull);


              return {
                tag: "animation",
                attributes: {
                  name: timelineMarker.name,
                },
                children: [
                  { tag: "attrlinks", children: attrLinkBlueprints },
                  { tag: "timedvalues", children: timedValueBlueprints },
                ],
              }
            }),
        };
      },
    ];

    var _progress = new progressBar.Process({
      title: "Saving XML Files",
      items: blueprintCallbacks.length,
    });

    var tagToFileName = /**@type Lookup<string, string>*/({
      stages: "stage",
      skeletons: "skeleton",
      animations: "animation",
      drawingAnimations: "drawingAnimation",
    });

    /**
     * @param {string} folderPath
     */
    var outputFolder = exportPath();
    blueprintCallbacks.forEach(function(blueprintCallback) {
      var blueprint = blueprintCallback();
      var fileName = tagToFileName[blueprint.tag] || blueprint.tag;
      _progress.tryIncrementCancellable(fileName + ".xml", "Saving XML File");
      FileUtil.mergeXMLFile(outputFolder + "/" + fileName + ".xml", {
        tag: blueprint.tag,
        attributes: blueprint.attributes,
        children: blueprint.children,
        overwrite: settings.overwriteProject,
        mergeChildAttribute: "name",
      });
    });

    if (spriteSheetXML != null) {
      FileUtil.saveString(outputFolder + "/spriteSheets.xml", new XML.Builder(spriteSheetXML).toXMLString());
    }

    return this;
  }

  this.complete = function() {
    var exportedTbg = null;
    if (settings.encodeToTBG) {
      _progress.tryIncrementCancellable(translator.tr("Archiving files to .tbg"));
      var savingPath = settings.savingPath;
      if (about.isGameStudio()) {
        var dir = new QDir(settings.savingPath);
        if (dir.isRelative()) {
          savingPath = FileUtil.currentProjectPath() + "/" + settings.savingPath;
          dir = new QDir(savingPath);
          savingPath = dir.absolutePath().replace("\\", "/");
        }
      }

      var finalPath = savingPath + "/" + settings.savingName + ".tbg";
      var temporaryPath = exportPath();
      MessageLog.trace(finalPath);
      new QFile(finalPath).remove();
      GameFileEncoder.saveFolderToArchive(temporaryPath, finalPath);
      FileUtil.removeFolder(temporaryPath);
      exportedTbg = finalPath;
    }

    MessageLog.trace("Export complete!");
    return exportedTbg;
  }
};

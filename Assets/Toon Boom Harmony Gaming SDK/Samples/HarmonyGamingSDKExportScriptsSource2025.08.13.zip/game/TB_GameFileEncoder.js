/**
 * @param {string} path 
 * @returns {string}
 */
exports.escapeSpaces = function (path) {
  if (about.isWindowsArch())
  {
    var v = "\"\"" + path + "\"\""
    return v;
  }
  return path;
}

/**
 * @param {string} inputFolder
 * @param {string} outputFile
 */
exports.saveFolderToArchive = function (inputFolder, outputFile) {
  var zipPath = System.find7Zip();
  if(zipPath.length == 0)
  {
    MessageBox.critical("Cannot find 7zip to save out .tbg file. Aborting");
    throw new Error("cannot find 7zip");
  }
  var process = new Process2(zipPath, "a", "-tzip", "-mx0", exports.escapeSpaces(outputFile), exports.escapeSpaces(inputFolder + "/*"));
  var processResult = process.launch();
  MessageLog.trace("Running command: " + process.commandLine())
  if (processResult != 0)
  {
    MessageLog.trace(process.errorCode())
    throw new Error("Archive process of file " + outputFile + " could not be completed.");
  }
  MessageLog.trace("File created: " + outputFile);
  return true;
}

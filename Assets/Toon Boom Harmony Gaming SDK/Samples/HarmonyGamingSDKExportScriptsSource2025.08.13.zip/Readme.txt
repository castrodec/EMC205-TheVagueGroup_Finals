=== Harmony Export Scripts ===

Scripts for Toon Boom Harmony software that allow the export of assets from Toon Boom Harmony into either a .tbg file or an unpacked XML folder. New export workflow enables features for exporting multiple palettes during a single export, "bake_" node group support for advanced effects baking/exporting, as well as a new .tbg file format that can be imported in Unity as a native heirarchy of Transforms and SpriteRenderers.

=== Installation ===

Copy the contents of this folder in the "resources/scripts" folder inside your Toon Boom Harmony install

* In Windows, this will be found under "Program Files (x86)/Toon Boom Animation/Toon Boom Harmony 24 Premium/resources/scripts"
* In MacOS
    * Navigate to your Harmony app in the Applications section of Finder
    * Right-click -> "show package contents"
    * Navigate through Contents/tba/resources/scripts

=== Usage ===

New scripts will override the existing "Export To Sprite Sheets" button in the Game toolbar, and can be used in the same way.
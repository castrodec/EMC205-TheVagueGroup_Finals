/*******************************************************************************
  Copyright 2003-2022 ToonBoom Technologies Inc. 2022

  The source code contained in this file is intended for INTERNAL USE ONLY.
  The content is strictly confidential and should not be distributed without
  prior explicit authorization.
*******************************************************************************/


#include "MT_Point3d.h"

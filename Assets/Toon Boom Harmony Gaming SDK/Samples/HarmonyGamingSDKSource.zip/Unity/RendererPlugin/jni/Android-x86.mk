LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_CPP_FEATURES := exceptions

APP_OPTIM := debug
LOCAL_ALLOW_UNDEFINED_SYMBOLS := true

LOCAL_C_INCLUDES := \
	$(ANDROID_NDK_ROOT)/platforms/android-16/arch-x86/usr/include \
	$(LOCAL_PATH)/.. \
	$(LOCAL_PATH)/../Base \
	$(LOCAL_PATH)/../Render \
	$(LOCAL_PATH)/../../../CoreCpp \
	$(LOCAL_PATH)/../../../CoreCpp/Base \
	$(LOCAL_PATH)/../../../CoreCpp/Bin \
	$(LOCAL_PATH)/../../../CoreCpp/Render \
	$(LOCAL_PATH)/../../../CoreCpp/Support \
	$(LOCAL_PATH)/../../../CoreCpp/Tree \
	$(LOCAL_PATH)/../../../CoreCpp/TreeView \
	$(LOCAL_PATH)/../../../CoreCpp/Xml \

# with c++11 support
LOCAL_CFLAGS := \
	-std=gnu++11 \
	-DSUPPORT_CXX11_STANDARD \
 	-DTARGET_ANDROID

# without c++11 support
#LOCAL_CFLAGS := \
 	-DTARGET_ANDROID

LOCAL_MODULE    := libHarmonyRenderer
LOCAL_SRC_FILES := \
../HarmonyRenderer/HarmonyRenderer.cpp \
../Base/PL_Atomic_unix.cpp \
../Base/PL_Mutex_unix.cpp \
../Base/UT_ShareBaseSafe.cpp \
../Base/UT_SharedWeakPtr.cpp \
../Render/RD_ClipData.cpp \
../Render/RD_Composition.cpp \
../Render/RD_RenderId.cpp \
../Render/RD_RenderScript.cpp \
../Render/RD_RenderScriptMeta.cpp \
../Render/RD_RenderScriptFx.cpp \
../Render/RD_SpriteSheet.cpp \
../../../CoreCpp/Base/IO_File.cpp \
../../../CoreCpp/Base/IO_PersistentStore.cpp \
../../../CoreCpp/Base/IO_Stream.cpp \
../../../CoreCpp/Base/MEM_CustomOverride.cpp \
../../../CoreCpp/Base/MEM_DebugOverride.cpp \
../../../CoreCpp/Base/MT_Matrix4x4.cpp \
../../../CoreCpp/Base/MT_Point3d.cpp \
../../../CoreCpp/Base/MT_Vector3d.cpp \
../../../CoreCpp/Base/PL_FileInfo.cpp \
../../../CoreCpp/Base/PL_FileSpec.cpp \
../../../CoreCpp/Base/UT_CVTUTF.cpp \
../../../CoreCpp/Base/UT_ShareBase.cpp \
../../../CoreCpp/Base/UT_String.cpp \
../../../CoreCpp/Bin/BIN_ProjectLoader.cpp \
../../../CoreCpp/Render/RD_ClipDataCore.cpp \
../../../CoreCpp/Render/RD_SpriteSheetCore.cpp \
../../../CoreCpp/Support/tinyxml2.cpp \
../../../CoreCpp/Tree/TR_CatmullCompute.cpp \
../../../CoreCpp/Tree/TR_DataObject.cpp \
../../../CoreCpp/Tree/TR_NodeTree.cpp \
../../../CoreCpp/Tree/TR_NodeTreeBuilder.cpp \
../../../CoreCpp/Tree/TR_Types.cpp \
../../../CoreCpp/Tree/TR_Utils.cpp \
../../../CoreCpp/TreeView/TV_BezierCurveView.cpp \
../../../CoreCpp/TreeView/TV_Blending.cpp \
../../../CoreCpp/TreeView/TV_CatmullCurveView.cpp \
../../../CoreCpp/TreeView/TV_ConstantFloatDataView.cpp \
../../../CoreCpp/TreeView/TV_EffectDataView.cpp \
../../../CoreCpp/TreeView/TV_FloatDataView.cpp \
../../../CoreCpp/TreeView/TV_NodeTreeView.cpp \
../../../CoreCpp/TreeView/TV_PivotDataView.cpp \
../../../CoreCpp/TreeView/TV_Pos3dDataView.cpp \
../../../CoreCpp/TreeView/TV_LinearCurveView.cpp \
../../../CoreCpp/Xml/XML_AnimationSaxParser.cpp \
../../../CoreCpp/Xml/XML_DrawingAnimationSaxParser.cpp \
../../../CoreCpp/Xml/XML_ProjectLoader.cpp \
../../../CoreCpp/Xml/XML_SaxParser.cpp \
../../../CoreCpp/Xml/XML_SkeletonSaxParser.cpp \
../../../CoreCpp/Xml/XML_SpriteSheetSaxParser.cpp \
../../../CoreCpp/Xml/XML_StageSaxParser.cpp

LOCAL_LDLIBS := -llog -lz 

include $(BUILD_SHARED_LIBRARY)

APP_STL:=gnustl_static
APP_ABI:=x86
APP_BUILD_SCRIPT := Android-x86.mk

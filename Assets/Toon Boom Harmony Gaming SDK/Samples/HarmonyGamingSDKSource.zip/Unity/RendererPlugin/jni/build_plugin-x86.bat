echo ""

echo "Cleanup"
rd /Q /S x86

echo ""
echo "Compiling for achitecture 'x86'"
%ANDROID_NDK_ROOT%/ndk-build -d NDK_PROJECT_PATH=x86 NDK_APPLICATION_MK=Application-x86.mk

echo ""
echo "Done!"

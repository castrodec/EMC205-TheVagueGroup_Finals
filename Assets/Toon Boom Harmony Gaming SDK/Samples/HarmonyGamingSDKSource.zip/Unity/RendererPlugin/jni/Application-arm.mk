APP_STL:=gnustl_static
APP_ABI:=armeabi-v7a
APP_BUILD_SCRIPT := Android-arm.mk

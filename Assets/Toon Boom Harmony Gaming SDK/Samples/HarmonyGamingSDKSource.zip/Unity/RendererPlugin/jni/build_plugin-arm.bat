echo ""

echo "Cleanup"
rd /Q /S arm

echo ""
echo "Compiling for achitecture 'arm'"
%ANDROID_NDK_ROOT%/ndk-build -d NDK_PROJECT_PATH=arm NDK_APPLICATION_MK=Application-arm.mk

echo ""
echo "Done!"

TARGET = Base

CONFIG -= qt
CONFIG += staticlib

include(../platform.pri)

TEMPLATE = lib

DESTDIR = ./

HEADERS += \
  PL_Atomic.h \
  PL_Mutex.h \
  UT_ShareBaseSafe.h \
  UT_SharedWeakPtr.h

SOURCES += \
  PL_Atomic_unix.cpp \
  PL_Atomic_win.cpp \
  PL_Mutex_unix.cpp \
  PL_Mutex_win.cpp \
  UT_ShareBaseSafe.cpp \
  UT_SharedWeakPtr.cpp

macx {
  OBJECTIVE_SOURCES += \
    PL_Atomic_mac.mm \
    PL_Mutex_mac.mm
}

INCLUDEPATH *= ../
INCLUDEPATH *= ../../../CoreCpp
INCLUDEPATH *= ../../../CoreCpp/Base
INCLUDEPATH *= ../../../CoreCpp/Render
INCLUDEPATH *= ../../../CoreCpp/Support
INCLUDEPATH *= ../../../CoreCpp/Tree
INCLUDEPATH *= ../../../CoreCpp/TreeView
INCLUDEPATH *= ../../../CoreCpp/Xml

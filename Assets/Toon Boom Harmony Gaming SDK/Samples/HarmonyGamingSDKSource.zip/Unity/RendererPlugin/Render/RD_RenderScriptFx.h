
#ifndef _RD_RENDER_SCRIPT_FX_H_
#define _RD_RENDER_SCRIPT_FX_H_

#include "RD_Composition.h"
#include "RD_SpriteSheet.h"
#include "RD_RenderScript.h"

#include "Base/STD_Types.h"
#include "Base/STD_Containers.h"

class RD_RenderScriptFx;

typedef UT_SharedPtr<RD_RenderScriptFx> RD_RenderScriptFxPtr_t;
typedef UT_SharedWeakPtr<RD_RenderScriptFx> RD_RenderScriptFxWeakPtr_t;

// #ifndef MAX_EFFECTS
// #define MAX_EFFECTS 15
// #endif

#define MAX_BONES_GPU    32
#define MAX_BONES_GPUf   32.0f

#define UNITY_SUPPORT

/*!
 *  @class RD_RenderScriptFx
 *  Rendering data for a single clip.
 */
class RD_RenderScriptFx : public RD_RenderScript
{
public:

  /*!
   *  @struct VertexData
   *  Vertex rendering parameters.
   */
  struct VertexData
  {
    float_t _x, _y, _z;

#ifndef UNITY_SUPPORT
    float_t _opacity;
#endif
    float_t _u0, _v0;
#ifdef UNITY_SUPPORT
    float_t _opacity;
#endif

    float_t _fxParams0[4];
    float_t _fxViewport0[4];

    float_t _boneParams[4];
  };
  
  /*!
   *  @struct BoneMapping
   *  Single vertex mapping to bone hierarchy.
   */
  struct TextureMapping
  {
      TextureMapping(int32_t textureId, int32_t maskTextureId, int32_t count) :
          _textureId(textureId),
          _maskTextureId(maskTextureId),
          _count(count)
      {
      }

      int32_t    _textureId;
      int32_t    _maskTextureId;
      int32_t    _count;
  };

  typedef STD_Vector<VertexData> VertexDataCol_t;

#ifdef UNITY_SUPPORT
  typedef uint16_t Index_t;
#else
  typedef uint32_t Index_t;
#endif
  typedef Index_t IndexPtr_t;

  typedef STD_Vector<Index_t> IndexDataCol_t;
  typedef STD_Vector<TextureMapping> TextureDataCol_t;

  /*!
   *  @struct BoneMatrix
   *  Raw matrix data.
   */
  struct BoneMatrix
  {
    float _data[16];
  };

  typedef STD_Vector< BoneMatrix > BoneMatrixCol_t;

  /*!
   *  @struct RenderBatch
   *  Batch rendering parameters.
   */
  struct RenderBatch
  {
    RD_SpriteSheetPtr_t _spriteSheet;
    unsigned            _indexOffset;
    unsigned            _nIndices;
    unsigned            _vertexOffset;
    unsigned            _nVertices;

    BoneMatrixCol_t     _uniformBoneMatrices;
  };

  typedef STD_Vector< RenderBatch > RenderBatchCol_t;

public:

  RD_RenderScriptFx();
  RD_RenderScriptFx(const RD_RenderScriptMetaPtr_t &);
  virtual ~RD_RenderScriptFx();

  virtual void update( const RD_ClipDataPtr_t &pClipData, int projectId, const STD_String &sheetResolution, float frame, int discretizationStep );
  virtual void updateWithBlending( const RD_ClipDataPtr_t &pClipDataFrom, int projectId, const STD_String &sheetResolution, float frameFrom, float frameTo, unsigned int color, int discretizationStep , float fullBlendTime, float currentBlendTime,int blendID );

  virtual bool supportsFeature( Feature feature ) const;

  static Feature supportedFeatures();

public:

  bool isDirty( float frame ) const;
  bool isRenderDirty() const;

  const VertexData *vertices() const;
  size_t verticesCount() const;

  const Index_t *indices() const;
  size_t indicesCount() const;

  const TextureMapping *textures() const;
  size_t texturesCount() const;

  const float *bones() const;
  size_t bonesCount() const;

protected:

  void cleanup();

  void clearSpriteMapping();

  void updateBatch( const RD_Composition *composition,
                    const RD_Composition::CompositionNodeCol_t::const_iterator iCompositionStart,
                    const RD_Composition::CompositionNodeCol_t::const_iterator iCompositionEnd,
                    RenderBatch &renderBatch );

private:

  class Impl;
  Impl *_i;

};

#endif /* _RD_RENDER_SCRIPT_FX_H_ */

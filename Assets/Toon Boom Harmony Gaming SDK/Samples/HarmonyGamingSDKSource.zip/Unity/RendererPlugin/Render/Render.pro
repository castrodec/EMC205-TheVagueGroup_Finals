TARGET = Render

CONFIG -= qt
CONFIG += staticlib

include(../platform.pri)

TEMPLATE = lib

DESTDIR = ./

HEADERS += \
  RD_ClipData.h \
  RD_Composition.h \
  RD_RenderId.h \
  RD_RenderObjectManager.h \
  RD_RenderScript.h \
  RD_RenderScriptMeta.h \
  RD_RenderScriptFx.h \
  RD_Renderer.h \
  RD_SpriteSheet.h

SOURCES += \
  RD_ClipData.cpp \
  RD_Composition.cpp \
  RD_RenderId.cpp \
  RD_RenderScript.cpp \
  RD_RenderScriptMeta.cpp \
  RD_RenderScriptFx.cpp \
  RD_SpriteSheet.cpp


INCLUDEPATH *= ../
INCLUDEPATH *= ../../../CoreCpp
INCLUDEPATH *= ../../../CoreCpp/Base
INCLUDEPATH *= ../../../CoreCpp/Render
INCLUDEPATH *= ../../../CoreCpp/Tree
INCLUDEPATH *= ../../../CoreCpp/TreeView
INCLUDEPATH *= ../../../CoreCpp/Xml

unix {
  QMAKE_CXXFLAGS_WARN_ON *= -Wno-invalid-offsetof
}

win32 {
  INCLUDEPATH *= $(DXSDK_DIR)/Include
}

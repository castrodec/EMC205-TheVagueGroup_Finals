#define PRX_EXPORT extern "C" __declspec (dllexport)

#if !defined(TARGET_PS4)
#include "pch.h"
#endif

#include <stdio.h>

#include "Base/MT_Matrix4x4.h"
#include "Base/MEM_Override.h"
#include "Base/STD_Containers.h"
#include "Base/STD_Types.h"
#include "Base/PL_Configure.h"
#include "Base/IO_Memory.h"
#include "Base/IO_PersistentStore.h"
#include "TreeView/TV_Blending.h"

#include "Render/RD_SpriteSheet.h"
#include "Render/RD_ClipData.h"
#include "Render/RD_RenderScript.h"

#include "Render/RD_RenderId.h"
#include "Render/RD_RenderObjectManager.h"

#include "Render/RD_RenderScriptFx.h"

#include "Tree/TR_NodeTree.h"
#include "TreeView/TV_NodeTreeView.h"

#include <set>

#define  LOG_TAG    "LogHarmony"
#define  ERROR_TAG  "ErrorHarmony"

#ifdef _DEBUG // TODO: Define this for Debug

#ifdef TARGET_ANDROID
#include <android/log.h>

#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,ERROR_TAG,__VA_ARGS__)
#else
#define  LOGI(...)  fprintf(stderr, "[%s] ", LOG_TAG );   fprintf(stderr, __VA_ARGS__)
#define  LOGE(...)  fprintf(stderr, "[%s] ", ERROR_TAG ); fprintf(stderr, __VA_ARGS__)
#endif

#else

#define  LOGI(...)
#define  LOGE(...)

#endif

//WARNING: Experimental feature - Use at your own risk.
//#define USE_ANIMATION_BLENDING

//namespace
//{
//	void dumpTree(const TV_NodeTreeViewPtr_t &nodeTreeView, const STD_String &prefix)
//	{
//		LOGI("%s[%s]\n", prefix.c_str(), nodeTreeView->name().c_str());
//
//		for (TV_NodeTreeView::BrotherIterator i = nodeTreeView->childBegin(), iEnd = nodeTreeView->childEnd(); i != iEnd; ++i)
//		{
//			dumpTree(&(*i), prefix + "  ");
//		}
//	}
//
//	bool testFeatures(RD_RenderScript::Feature requestedFeatures, RD_RenderScript::Feature supportedFeatures)
//	{
//		return (requestedFeatures & supportedFeatures) == requestedFeatures;
//
//	}
//}

PRX_EXPORT int CreateRenderScript(int projectId, const char *clipName)
{
	RD_ClipDataKey key(projectId, clipName);
	RD_ClipDataPtr_t pClipData = RD_ClipDataManager::instance()->object(key);
	if (pClipData.get() == 0)
	{
		LOGE("Clip '%s' has not been loaded in memory!\n", clipName);
		return -1;
	}

	if (pClipData->count() > 0)
	{
		RD_RenderScript::Feature requestedFeatures = RD_RenderScript::ePlainFeature;
		if (pClipData->fxEnabled())
			requestedFeatures = RD_RenderScript::Feature(requestedFeatures | RD_RenderScript::eCutterFeature | RD_RenderScript::eDeformationFeature);

		RD_RenderScriptPtr_t pRenderScript = new RD_RenderScriptFx;

		int scriptId = RD_RenderId::uniqueId();
		RD_RenderScriptManager::instance()->addObject(scriptId, pRenderScript);
		return scriptId;
	}

	return -1;
}

PRX_EXPORT int UpdateRenderScript(int scriptId, int projectId, const char *clipName, const char *sheetResolution, float frame, int discretizationStep)
{
	RD_RenderScriptPtr_t pRenderScript = RD_RenderScriptManager::instance()->object(scriptId);

	RD_ClipDataKey key(projectId, clipName);
	RD_ClipDataPtr_t pClipData = RD_ClipDataManager::instance()->object(key);
	if (pClipData.get() == 0)
	{
		LOGE("Clip '%s' has not been loaded in memory!\n", clipName);
		return -1;
	}

	if (pClipData->count() > 0)
	{
		bool newScript = false;

		RD_RenderScript::Feature requestedFeatures = RD_RenderScript::ePlainFeature;
		if (pClipData->fxEnabled())
			requestedFeatures = RD_RenderScript::Feature(requestedFeatures | RD_RenderScript::eCutterFeature | RD_RenderScript::eDeformationFeature);

		//  Todo.  Implement a proper factory class to instantiate render scripts depending on
		//  requested features.
		if (pRenderScript.isValid())
		{
			if (!pRenderScript->supportsFeature(requestedFeatures))
			{
				//  Forward meta information to new script...
				RD_RenderScriptMetaPtr_t pMeta = pRenderScript->meta();

				//  Create new render script to support requested features.
				RD_RenderScriptManager::instance()->eraseObject(scriptId);

				pRenderScript = new RD_RenderScriptFx(pMeta);
				newScript = true;
			}
		}
		else
		{
			pRenderScript = new RD_RenderScriptFx;
			newScript = true;
		}

		pRenderScript->update(pClipData, projectId, sheetResolution, frame, discretizationStep);

		if (newScript)
		{
			RD_RenderScriptManager::instance()->addObject(scriptId, pRenderScript);
		}

		return scriptId;
	}

	return -1;
}

PRX_EXPORT void UnloadRenderScript(int scriptId)
{
	LOGI("Unloading Render Script id: 0x%x\n", scriptId);

	//  Erase render script from manager list.
	RD_RenderScriptManager::instance()->eraseObject(scriptId);
}

PRX_EXPORT float GetClipLength(int projectId, const char *clipName)
{
	RD_ClipDataKey key(projectId, clipName);
	RD_ClipDataPtr_t pClipData = RD_ClipDataManager::instance()->object(key);
	if (pClipData.isValid())
	{
		return pClipData->totalDuration();
	}

	return 0.0f;
}

PRX_EXPORT int LoadProject(int projectId, const char* projectData, int projectDataLength)
{
	LOGI("Loading Project '%d'\n", projectId);

	IO_Memory memory(projectData, projectDataLength);

	IO_PersistentStore store(memory);

	int clipCount;
	store >> clipCount;

	// Skip over clip names which are only for the header
	for (int i = 0; i < clipCount; ++i)
	{
		STD_String clipName;
		float clipLength;
		store >> clipName;
		store >> clipLength;
	}

	int sheetCount;
	store >> sheetCount;

	// Skip over sheet names which are only for the header
	for (int i = 0; i < sheetCount; ++i)
	{
		STD_String sheetName;
		STD_String sheetResolution;
		store >> sheetName;
		store >> sheetResolution;
	}

	for (int i = 0; i < clipCount; ++i)
	{
		RD_ClipDataCore *clipDataCore = new RD_ClipDataCore;
		if (!clipDataCore->load(store))
		{
			return 0;
		}

		RD_ClipDataPtr_t pClipData = new RD_ClipData(projectId, clipDataCore);
		RD_ClipDataKey key(projectId, pClipData->clipName());
		RD_ClipDataManager::instance()->addObject(key, pClipData);
	}

	for (int i = 0; i < sheetCount; ++i)
	{
		RD_SpriteSheetCore *spriteSheetCore = new RD_SpriteSheetCore;
		if (!spriteSheetCore->load(store))
		{
			return 0;
		}

		RD_SpriteSheetPtr_t pSpriteSheet = new RD_SpriteSheet(projectId, spriteSheetCore);

		RD_SpriteSheetKey key(projectId, pSpriteSheet->sheetName(), pSpriteSheet->sheetResolution());
		RD_SpriteSheetManager::instance()->addObject(key, pSpriteSheet);
	}

	return clipCount;
}

PRX_EXPORT void UnloadProject(int projectId)
{
	LOGI("Unloading Project '%d'\n", projectId);

	// Erase clips from the manager list
	size_t nClips = RD_ClipDataManager::instance()->size();

	typedef STD_Set< RD_ClipDataKey > ClipDataKeyCol_t;
	ClipDataKeyCol_t clipsToDelete;

	for (unsigned idx = 0; idx < nClips; ++idx)
	{
		RD_ClipDataPtr_t pClip = RD_ClipDataManager::instance()->objectAt(idx);
		if (pClip.isValid())
		{
			//  Sprite sheet is part of project.
			if (pClip->projectId() == projectId)
			{
				clipsToDelete.insert(RD_ClipDataKey(pClip->projectId(), pClip->clipName()));
			}
		}
	}

	//  Erase matching clips from manager.
	for (ClipDataKeyCol_t::const_iterator i = clipsToDelete.begin(), iEnd = clipsToDelete.end(); i != iEnd; ++i)
	{
		LOGI("Unloading Clip ('%d':'%s')\n", i->_projectId, i->_clipName.c_str());
		RD_ClipDataManager::instance()->eraseObject(*i);
	}

	//  Erase sprite sheets from manager list.
	//  This bit must be called in the worker thread and is thread-safe with rendering thread
	//  that cannot create rendering objects on its own.

	size_t nSpritesheets = RD_SpriteSheetManager::instance()->size();

	typedef STD_Set< RD_SpriteSheetKey > SpriteSheetKeyCol_t;
	SpriteSheetKeyCol_t spritesToDelete;

	for (unsigned idx = 0; idx < nSpritesheets; ++idx)
	{
		RD_SpriteSheetPtr_t pSpriteSheet = RD_SpriteSheetManager::instance()->objectAt(idx);
		if (pSpriteSheet.isValid())
		{
			//  Sprite sheet is part of project.
			if (pSpriteSheet->projectId() == projectId)
			{
				spritesToDelete.insert(RD_SpriteSheetKey(pSpriteSheet->projectId(), pSpriteSheet->sheetName(), pSpriteSheet->sheetResolution()));
			}
		}
	}

	//  Erase matching sprite sheets from manager.
	for (SpriteSheetKeyCol_t::const_iterator i = spritesToDelete.begin(), iEnd = spritesToDelete.end(); i != iEnd; ++i)
	{
		LOGI("Unloading Sprite Sheet ('%d':'%s') Resolution: '%s'\n", i->_projectId, i->_sheetName.c_str(), i->_resolutionName.c_str());
		RD_SpriteSheetManager::instance()->eraseObject(*i);
	}
}

PRX_EXPORT bool CalculateLocatorTransform(int projectId, const char *clipName, float frame, const char *locatorName, float *position, float *rotation, float *scale)
{
	RD_ClipDataKey key(projectId, clipName);
	RD_ClipDataPtr_t pClipData = RD_ClipDataManager::instance()->object(key);
	if (pClipData.get() == 0)
	{
		LOGE("Clip '%s' has not been loaded in memory!\n", clipName);
		return false;
	}

	for (unsigned i = 0, iEnd = (unsigned)pClipData->count(); i < iEnd; ++i)
	{
		TV_NodeTreeViewPtr_t nodeTreeView = pClipData->nodeTreeView(i);
		TV_NodeTreeViewPtr_t locatorNodeTreeView = nodeTreeView->find(locatorName);

		if (locatorNodeTreeView.get())
		{
			float pivotx, pivoty, pivotz;
			locatorNodeTreeView->pivot(frame, pivotx, pivoty, pivotz);

			Math::Matrix4x4 modelMatrix = locatorNodeTreeView->modelMatrix(frame);

			modelMatrix.translate(pivotx, pivoty, pivotz);

			double tx, ty, tz, sx, sy, az, sk;
			if (modelMatrix.extractParameters(true, true, 0.0, 0.0, tx, ty, tz, sx, sy, az, sk))
			{
				position[0] = (float)tx;
				position[1] = (float)ty;
				position[2] = (float)tz;

				rotation[0] = rotation[1] = 0.0f;
				rotation[2] = (float)az;

				scale[0] = (float)sx;
				scale[1] = (float)sy;
				scale[2] = 1.0f;

				return true;
			}
		}
	}

	return false;
}

PRX_EXPORT bool GetModelData(int scriptId, RD_RenderScriptFx::VertexData **vertexData, int *vertexCount, RD_RenderScriptFx::Index_t **indexData, int *indexCount)
{
	RD_RenderScriptPtr_t pRenderScript = RD_RenderScriptManager::instance()->object(scriptId);
	if (!pRenderScript.isValid())
		return false;

	RD_RenderScriptFx *pRenderScriptFx = static_cast<RD_RenderScriptFx *>(pRenderScript.GetPtr());
	if (pRenderScriptFx != NULL)
	{
		*vertexData = const_cast<RD_RenderScriptFx::VertexData *>(pRenderScriptFx->vertices());
		*vertexCount = pRenderScriptFx->verticesCount();
		*indexData = const_cast<RD_RenderScriptFx::Index_t *>(pRenderScriptFx->indices());
		*indexCount = pRenderScriptFx->indicesCount();

		return true;
	}

	return false;
}

PRX_EXPORT bool GetBoneData(int scriptId, float **boneData, int *boneCount)
{
	RD_RenderScriptPtr_t pRenderScript = RD_RenderScriptManager::instance()->object(scriptId);
	if (!pRenderScript.isValid())
		return false;

	RD_RenderScriptFx *pRenderScriptFx = static_cast<RD_RenderScriptFx *>(pRenderScript.GetPtr());
	if (pRenderScriptFx != NULL)
	{
		*boneCount = pRenderScriptFx->bonesCount();

		if (*boneCount > 0)
		{
			*boneData = const_cast<float *>(pRenderScriptFx->bones());
		}
		else
		{
			*boneData = NULL;
		}

		return true;
	}

	return false;
}

PRX_EXPORT int CreateProp(int scriptId, int projectId, const char *clipName, const char *playName)
{
	LOGI("Creating prop for play sequence '%s' in clip '%s'\n", playName, clipName);
	RD_RenderScriptPtr_t pRenderScript = RD_RenderScriptManager::instance()->object(scriptId);
	if (pRenderScript.get() == 0)
	{
		LOGE("No valid rendering script for script id '0x%x'\n", scriptId);
		return -1;
	}

	RD_ClipDataKey key(projectId, clipName);
	RD_ClipDataPtr_t pPropData = RD_ClipDataManager::instance()->object(key);
	if (pPropData.get() == 0)
	{
		LOGE("Prop clip '%s' has not been loaded.\n", clipName);
		return -1;
	}

	TV_NodeTreeViewPtr_t propNodeTreeView = pPropData->nodeTreeView(playName);
	if (!propNodeTreeView.isValid())
	{
		LOGE("No valid hierarchy for prop '%s' in prop clip '%s'\n", playName, clipName);
		return -1;
	}

	return pRenderScript->createProp(playName, propNodeTreeView);
}

PRX_EXPORT void UpdateProp(int scriptId, int propId, float frame)
{
	LOGI("Updating propId '0x%x'\n", propId);
	RD_RenderScriptPtr_t pRenderScript = RD_RenderScriptManager::instance()->object(scriptId);
	if (!pRenderScript.isValid())
	{
		LOGE("Could not find script with id '0x%x'\n", scriptId);
		return;
	}

	pRenderScript->updateProp(propId, frame);
}

PRX_EXPORT void AnchorProp(int scriptId, int propId, const char *playName, const char *nodeName)
{
	LOGI("Anchoring propId '0x%x' to '%s' in parent play sequence '%s'\n", propId, nodeName, playName);
	RD_RenderScriptPtr_t pRenderScript = RD_RenderScriptManager::instance()->object(scriptId);
	if (!pRenderScript.isValid())
	{
		LOGE("Could not find script with id '0x%x'\n", scriptId);
		return;
	}

	pRenderScript->anchorProp(propId, playName, nodeName);
}

PRX_EXPORT void UnanchorProp(int scriptId, int propId)
{
	LOGI("Unanchoring propId '0x%x'\n", propId);
	RD_RenderScriptPtr_t pRenderScript = RD_RenderScriptManager::instance()->object(scriptId);
	if (!pRenderScript.isValid())
	{
		LOGE("Could not find script with id '0x%x'\n", scriptId);
		return;
	}

	pRenderScript->unanchorProp(propId);
}

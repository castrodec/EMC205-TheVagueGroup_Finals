unix:!macx:CONFIG *= linux

win32 {
  isWin64=$$(Platform)
  
  isEmpty(isWin64) {
    PLATFORM       = win32
    OBJECTS_DIR    = ./obj_win32
    QMAKE_LFLAGS  *= /MACHINE:X86
    QMAKE_MAKEFILE = Makefile.32
    DLLDESTDIR     = win32
  }

  !isEmpty(isWin64) {
    PLATFORM       = win64
    DEFINES       *= WIN64
    OBJECTS_DIR    = ./obj_win64
    QMAKE_LFLAGS  *= /MACHINE:X64
    QMAKE_MAKEFILE = Makefile.64
    DLLDESTDIR     = win64

    CONFIG      *= win64
  }

  DEFINES *= TARGET_DESKTOP TARGET_WIN32
  # DEFINES *= SUPPORT_CXX11_STANDARD
}

linux {
  PLATFORM = lnx86_64
  OBJECTS_DIR = ./obj_lnx64

  DEFINES *= TARGET_DESKTOP TARGET_LINUX
  # DEFINES *= SUPPORT_CXX11_STANDARD

  # QMAKE_CXXFLAGS         *= -std=c++11
}

macx {
  CONFIG += x86 x86_64
  PLATFORM = macosx
  OBJECTS_DIR = ./obj_macosx

  DEFINES *= TARGET_DESKTOP TARGET_MAC
  # DEFINES *= SUPPORT_CXX11_STANDARD

  # required by clang 4.2 when linking with libc++
  # QMAKE_MACOSX_DEPLOYMENT_TARGET = 10.7

  # QMAKE_CXXFLAGS         *= -stdlib=libc++ -std=c++11
  # QMAKE_OBJECTIVE_CFLAGS *= -stdlib=libc++ -std=c++11
  # QMAKE_LFLAGS           *= -stdlib=libc++
}

TARGET = CoreCpp

CONFIG -= qt
CONFIG += staticlib

include(../platform.pri)

TEMPLATE = lib

DESTDIR = ./

HEADERS += \
  ../../../CoreCpp/Base/IO_File.h \
  ../../../CoreCpp/Base/IO_PersistentStore.h \
  ../../../CoreCpp/Base/IO_Stream.h \
  ../../../CoreCpp/Base/MEM_Override.h \
  ../../../CoreCpp/Base/MEM_CustomOverride.h \
  ../../../CoreCpp/Base/MEM_DebugOverride.h \
  ../../../CoreCpp/Base/MT_Matrix4x4.h \
  ../../../CoreCpp/Base/MT_Point3d.h \
  ../../../CoreCpp/Base/MT_TypeDefinitions.h \
  ../../../CoreCpp/Base/MT_Vector3d.h \
  ../../../CoreCpp/Base/PL_FileInfo.h \
  ../../../CoreCpp/Base/PL_FileSpec.h \
  ../../../CoreCpp/Base/STD_Containers.h \
  ../../../CoreCpp/Base/STD_Types.h \
  ../../../CoreCpp/Base/UT_CVTUTF.h \
  ../../../CoreCpp/Base/UT_ShareBase.h \
  ../../../CoreCpp/Base/UT_SharedPtr.h \
  ../../../CoreCpp/Base/UT_String.h \
  #../../../CoreCpp/Bin/BIN_ProjectLoader.h \
  ../../../CoreCpp/Render/RD_ClipDataCore.h \
  ../../../CoreCpp/Render/RD_SpriteSheetCore.h \
  ../../../CoreCpp/Support/tinyxml2.h \
  ../../../CoreCpp/Tree/TR_CatmullCompute.h \
  ../../../CoreCpp/Tree/TR_DataObject.h \
  ../../../CoreCpp/Tree/TR_NodeTree.h \
  ../../../CoreCpp/Tree/TR_NodeTreeBuilder.h \
  ../../../CoreCpp/Tree/TR_Types.h \
  ../../../CoreCpp/Tree/TR_Utils.h \
  ../../../CoreCpp/TreeView/TV_Blending.h \
  ../../../CoreCpp/TreeView/TV_BezierCurveView.h \
  ../../../CoreCpp/TreeView/TV_CatmullCurveView.h \
  ../../../CoreCpp/TreeView/TV_ConstantFloatDataView.h \
  ../../../CoreCpp/TreeView/TV_EffectDataView.h \
  ../../../CoreCpp/TreeView/TV_FloatDataView.h \
  ../../../CoreCpp/TreeView/TV_LinearCurveView.h \
  ../../../CoreCpp/TreeView/TV_NodeTreeView.h \
  ../../../CoreCpp/TreeView/TV_PivotDataView.h \
  ../../../CoreCpp/TreeView/TV_Pos3dDataView.h \
  ../../../CoreCpp/Xml/XML_AnimationSaxParser.h \
  ../../../CoreCpp/Xml/XML_DrawingAnimationSaxParser.h \
  ../../../CoreCpp/Xml/XML_ProjectLoader.h \
  ../../../CoreCpp/Xml/XML_SaxParser.h \
  ../../../CoreCpp/Xml/XML_SkeletonSaxParser.h \
  ../../../CoreCpp/Xml/XML_SpriteSheetSaxParser.h \
  ../../../CoreCpp/Xml/XML_StageSaxParser.h

SOURCES += \
  ../../../CoreCpp/Base/IO_File.cpp \
  ../../../CoreCpp/Base/IO_PersistentStore.cpp \
  ../../../CoreCpp/Base/IO_Stream.cpp \
  ../../../CoreCpp/Base/MEM_CustomOverride.cpp \
  ../../../CoreCpp/Base/MEM_DebugOverride.cpp \
  ../../../CoreCpp/Base/MT_Matrix4x4.cpp \
  ../../../CoreCpp/Base/MT_Point3d.cpp \
  ../../../CoreCpp/Base/MT_Vector3d.cpp \
  ../../../CoreCpp/Base/PL_FileInfo.cpp \
  ../../../CoreCpp/Base/PL_FileSpec.cpp \
  ../../../CoreCpp/Base/UT_ShareBase.cpp \
  ../../../CoreCpp/Base/UT_CVTUTF.cpp \
  ../../../CoreCpp/Base/UT_String.cpp \
  #../../../CoreCpp/Bin/BIN_ProjectLoader.cpp \
  ../../../CoreCpp/Render/RD_ClipDataCore.cpp \
  ../../../CoreCpp/Render/RD_SpriteSheetCore.cpp \
  ../../../CoreCpp/Support/tinyxml2.cpp \
  ../../../CoreCpp/Tree/TR_CatmullCompute.cpp \
  ../../../CoreCpp/Tree/TR_DataObject.cpp \
  ../../../CoreCpp/Tree/TR_NodeTree.cpp \
  ../../../CoreCpp/Tree/TR_NodeTreeBuilder.cpp \
  ../../../CoreCpp/Tree/TR_Types.cpp \
  ../../../CoreCpp/Tree/TR_Utils.cpp \
  ../../../CoreCpp/TreeView/TV_Blending.cpp \
  ../../../CoreCpp/TreeView/TV_BezierCurveView.cpp \
  ../../../CoreCpp/TreeView/TV_CatmullCurveView.cpp \
  ../../../CoreCpp/TreeView/TV_ConstantFloatDataView.cpp \
  ../../../CoreCpp/TreeView/TV_EffectDataView.cpp \
  ../../../CoreCpp/TreeView/TV_FloatDataView.cpp \
  ../../../CoreCpp/TreeView/TV_LinearCurveView.cpp \
  ../../../CoreCpp/TreeView/TV_NodeTreeView.cpp \
  ../../../CoreCpp/TreeView/TV_PivotDataView.cpp \
  ../../../CoreCpp/TreeView/TV_Pos3dDataView.cpp \
  ../../../CoreCpp/Xml/XML_AnimationSaxParser.cpp \
  ../../../CoreCpp/Xml/XML_DrawingAnimationSaxParser.cpp \
  ../../../CoreCpp/Xml/XML_ProjectLoader.cpp \
  ../../../CoreCpp/Xml/XML_SaxParser.cpp \
  ../../../CoreCpp/Xml/XML_SkeletonSaxParser.cpp \
  ../../../CoreCpp/Xml/XML_SpriteSheetSaxParser.cpp \
  ../../../CoreCpp/Xml/XML_StageSaxParser.cpp

macx {
  OBJECTIVE_SOURCES *= ../../../CoreCpp/Base/PL_FileSpec_mac.mm
}

INCLUDEPATH *= ../../../CoreCpp
INCLUDEPATH *= ../../../CoreCpp/Base
INCLUDEPATH *= ../../../CoreCpp/Render
INCLUDEPATH *= ../../../CoreCpp/Support
INCLUDEPATH *= ../../../CoreCpp/Tree
INCLUDEPATH *= ../../../CoreCpp/TreeView
INCLUDEPATH *= ../../../CoreCpp/Xml


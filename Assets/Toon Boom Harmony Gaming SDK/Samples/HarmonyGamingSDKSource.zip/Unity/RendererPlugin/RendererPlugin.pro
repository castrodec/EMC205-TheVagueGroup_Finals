TEMPLATE = subdirs
CONFIG += ordered

include (platform.pri)

SUBDIRS = \
  CoreCpp \
  Support \
  Base \
  Render \
  HarmonyRenderer


SRCROOT = $$PWD/..

include (../platform.pri)

macx {
  TEMPLATE = lib
  CONFIG += lib_bundle
  CONFIG += dll

  QMAKE_BUNDLE_EXTENSION = .bundle

  QMAKE_LFLAGS += -framework Foundation

  # Unity searches for library in .bundle/Contents/MacOS, create folder manually.
  QMAKE_POST_LINK = rm -fr HarmonyRenderer.bundle/Contents/MacOS ; mkdir HarmonyRenderer.bundle/Contents/MacOS ; ln -s ../../HarmonyRenderer HarmonyRenderer.bundle/Contents/MacOS/HarmonyRenderer 
}

win32 {
  TEMPLATE = lib
}

linux {
  TEMPLATE = lib
}

CONFIG -= qt
CONFIG += opengl

include($$SRCROOT/Render/Render.pru)
include($$SRCROOT/Base/Base.pru)
include($$SRCROOT/CoreCpp/CoreCpp.pru)

#include($$SRCROOT/Support/Support.pru)

INCLUDEPATH *= $$SRCROOT
INCLUDEPATH *= $$SRCROOT/../../CoreCpp
INCLUDEPATH *= $$SRCROOT/../../CoreCpp/Base
INCLUDEPATH *= $$SRCROOT/../../CoreCpp/Render
INCLUDEPATH *= $$SRCROOT/../../CoreCpp/Tree
INCLUDEPATH *= $$SRCROOT/../../CoreCpp/TreeView
INCLUDEPATH *= $$SRCROOT/../../CoreCpp/Xml


HEADERS += \
  HarmonyRenderer.h

SOURCES += \
  HarmonyRenderer.cpp


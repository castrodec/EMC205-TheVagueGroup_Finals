unix:!macx:CONFIG *= linux

win32 {
  isWin64=$$(Platform)
  
  isEmpty(isWin64) {
    PLATFORM       = win32
	MOC_DIR        = ./moc_win32
    OBJECTS_DIR    = ./obj_win32
    QMAKE_LFLAGS  *= /MACHINE:X86
	!contains(TEMPLATE, vclib):!contains(TEMPLATE, vcapp) {
      QMAKE_MAKEFILE = Makefile.32
	}
  }

  !isEmpty(isWin64) {
    PLATFORM       = win64
    DEFINES       *= WIN64
    MOC_DIR        = ./moc_win64
    OBJECTS_DIR    = ./obj_win64
    QMAKE_LFLAGS  *= /MACHINE:X64
    !contains(TEMPLATE, vclib):!contains(TEMPLATE, vcapp) {
      QMAKE_MAKEFILE = Makefile.64
    }

    CONFIG      *= win64
  }

  DEFINES *= TARGET_DESKTOP TARGET_WIN32
  DEFINES *= SUPPORT_CXX11_STANDARD
}

linux {
  PLATFORM = lnx86_64
  OBJECTS_DIR = ./obj_lnx64

  DEFINES *= TARGET_DESKTOP TARGET_LINUX
  DEFINES *= SUPPORT_CXX11_STANDARD
}

macx {
  CONFIG += x86 x86_64
  PLATFORM = macosx
  OBJECTS_DIR = ./obj_macosx

  DEFINES *= TARGET_DESKTOP TARGET_MAC
}

